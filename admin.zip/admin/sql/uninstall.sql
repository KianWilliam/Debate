DROP TABLE IF EXISTS `#__debate`;
DROP TABLE IF EXISTS `#__debate_thread_id`;
DROP TABLE IF EXISTS `#__debate_user_ip_address`;
DROP TABLE IF EXISTS `#__debate_subscriptions`;
DROP TABLE IF EXISTS `#__debate_forum_rules`;
DROP TABLE IF EXISTS `#__debate_fonders`;
DROP TABLE IF EXISTS `#__debate_config`;
DROP TABLE IF EXISTS `#__debate_deprive_users`;
DROP TABLE IF EXISTS `#__debate_badpost_users`;
DROP TABLE IF EXISTS `#__debate_edit_users`;
DROP TABLE IF EXISTS `#__debate_deprive_list`;


