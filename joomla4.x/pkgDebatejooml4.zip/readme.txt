com_debate version 1.0.0  is a free software which is developed by kwproductions Co. 
https://kwproductions121.com, senior manager: Kian William Nowrouzian. 
It is a package including both component and plugin, Plugin will be enabled automatically from Joomla backend,
yet check it after upload in your site. 
Employ TinyMCE editor with advanced preset of joomla to get the best result of this extension.
Plugin cloak email of joomla should be enabled too.
In backend when you want to edit a message as just edited, bad post or deprive a user, your actions shall be reflected on other layouts,
Security measures have been taken to support you in case of making mistakes you will be able to reverse your mistakes.
In sitepart, categories layout could show rss feeds only when new messages are added and the feed is only for new message in categories layout.
Search in site part is based on title (for category layout) and content (for message layout), for security reasons search is not based on date of message.
Also in backend to prevent user of this extension from making mistakes, Search in back part could be done singularly rather than collectively.
Deprive List user layout won't be deleted for your records unless you delete the list directly, this layout is not in connection with badpost, depriveusers and editmessages layout.
The last three are all in connection with each other.
For simplicity I did not creat a separate add users to forum, this extension is using joomla's user extension direct, so anybody who is going to be a user of the forum must first
be a registered user of Joomla related site.
You can create  menuitems for categories and category, the extension is served for a local medium sized forum so I did not consider menuitems for individual messages and 
posts. 
Also joomla color picker might not work, in that case email me , to develop a custom color picker. (It is joomla issue no connection with this extension)
The license is GNU/GPLv3.
When a user registers to your site a folder in user's username shall be added to media (images/username)
Once you make jce default editor and make below changes to jce whenever a user attachs
an image to the message, the dialog box will be opened to user's folder only and there is no
access to backend images of the site or other users:
Choose default profile
jce>setup tab: add the user group of the user (e.g registered group)
jce>Editor properties>File system in file directory path input: images/$username
Also from global options of jce make the registered users ' access to com_jce allowed, permission should be set

It is written for Joomla 3.x and Joomla 4, the joomla 4alpha version shall be prepared soon.
demo :https://soulart.joomla.com/debate-for-art.html
download :https://www.extensions.kwproductions121.com/mycomponents/debate-download.html
In case of any problem contact me at:
webarchitect@kwproductions121.com
mezmer121@gmail.com
long live science.
